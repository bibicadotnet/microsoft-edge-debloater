// ==UserScript==
// @name         GDrive DL
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Tải file GDrive trực tiếp
// @author       You
// @match        https://drive.google.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const btn = document.createElement('button');
    btn.textContent = 'DL';
    btn.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:9999;padding:10px;background:#1a73e8;color:white;border:none;border-radius:50%;cursor:pointer;width:50px;height:50px;';

    btn.onclick = () => {
        const id = window.location.href.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1];
        if (id) {
            window.open(`https://drive.google.com/uc?export=download&id=${id}`, '_blank');
            return;
        }

        const selected = document.querySelectorAll('[data-id][aria-selected="true"]');
        const fileIds = [...selected]
            .map(item => item.getAttribute('data-id'))
            .filter(id => id && !selected[0]?.textContent.includes('Folder'));

        if (fileIds.length) {
            fileIds.forEach(id => window.open(`https://drive.google.com/uc?export=download&id=${id}`, '_blank'));
        } else {
            alert('Không tìm thấy file!');
        }
    };

    document.body.appendChild(btn);
})();